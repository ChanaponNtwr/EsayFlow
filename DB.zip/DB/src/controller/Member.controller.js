const { client } = require('../configs/database.config');
const uuid = require('uuid')
const controller = {
  

}
// API ดึงสมาชิกทั้งหมด
app.get("/api/members", (req, res) => {
    res.json(members);
  });

  // API เพิ่มสมาชิก
app.post("/api/members/add", (req, res) => {
    const { id } = req.body;
    const userToAdd = availableUsers.find((user) => user.id === parseInt(id));
  
    if (!userToAdd) {
      return res.status(404).send("ไม่พบผู้ใช้ที่ต้องการเพิ่ม");
    }
  
    if (members.some((member) => member.id === userToAdd.id)) {
      return res.status(400).send("สมาชิกนี้อยู่ในทีมแล้ว");
    }
  
    const newMember = {
      id: userToAdd.id,
      name: userToAdd.name,
      role: "Member", // กำหนด role เริ่มต้นเป็น Member
      image: userToAdd.image,
    };
  
    members.push(newMember);
  
    const notification = {
      id: notifications.length ? notifications[notifications.length - 1].id + 1 : 1,
      name: "System",
      message: `สมาชิก ${newMember.name} ถูกเพิ่มในทีม`,
      image: "https://img2.pic.in.th/pic/message_8604199.md.png",
    };
    notifications.push(notification);
  
    res.status(201).json(newMember);
  });
  
  // API ลบสมาชิก
  app.delete("/api/members/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const index = members.findIndex((member) => member.id === id);
    if (index === -1) {
      return res.status(404).send("ไม่พบสมาชิกที่ต้องการลบ");
    }
    const member = members[index];
    members.splice(index, 1);
  
    const notification = {
      id: notifications.length
        ? notifications[notifications.length - 1].id + 1
        : 1,
      name: "System",
      message: `สมาชิก ${member.name} ถูกลบออกจากทีม`,
      image: "https://img2.pic.in.th/pic/message_8604199.md.png",
    };
    notifications.push(notification);
  
    res.send("ลบสมาชิกสำเร็จ");
  });


// API ค้นหาสมาชิก
app.get("/api/members/search", (req, res) => {
    const query = req.query.q ? req.query.q.toLowerCase() : "";
    if (!query) {
      return res.json([]);
    }
  
    // กรองผู้ใช้ที่ยังไม่ได้อยู่ในทีม
    const filteredUsers = availableUsers
      .filter((user) => 
        user.name.toLowerCase().includes(query) && 
        !members.some((member) => member.id === user.id)
      );
    
    res.json(filteredUsers);
  });