
const { client } = require('../configs/database.config');
const uuid = require('uuid')
const controller = {
  addIngredient(req,res){
    const addIngredient = `
    INSERT INTO MyIngredient ()`

  }
  

}
// API ดึงส่วนผสมทั้งหมด (My Ingredient)
app.get("/api/ingredients", (req, res) => {
    res.json(ingredients);
  });

  // API เพิ่มส่วนผสมใหม่ (My Ingredient)
app.post("/api/ingredients", (req, res) => {
    const { name, quantity, weight, image, favorite ,allergies  } = req.body;
    const newIngredient = {
      id: ingredients.length ? ingredients[ingredients.length - 1].id + 1 : 1,
      name,
      quantity,
      weight,
      image,
      favorite,
      allergies,
    };
    ingredients.push(newIngredient);
    res.status(201).json(newIngredient);
  });
  
  // API อัปเดตส่วนผสม (My Ingredient)
  app.put("/api/ingredients/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const { name, quantity, weight, image, favorite ,allergies} = req.body;
    const index = ingredients.findIndex((item) => item.id === id);
    if (index === -1) {
      return res.status(404).send("ไม่พบส่วนผสมที่ต้องการอัปเดต");
    }
    ingredients[index] = { id, name, quantity, weight, image, favorite , allergies };
    res.json(ingredients[index]);
  });
  
  // API ลบส่วนผสม (My Ingredient)
  app.delete("/api/ingredients/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const index = ingredients.findIndex((item) => item.id === id);
    if (index === -1) {
      return res.status(404).send("ไม่พบส่วนผสมที่ต้องการลบ");
    }
    const ingredient = ingredients[index];
    ingredients.splice(index, 1);
  
    const notification = {
      id: notifications.length
        ? notifications[notifications.length - 1].id + 1
        : 1,
      name: "System",
      message: `วัตถุดิบ ${ingredient.name} ถูกลบออกจากรายการ`,
      image: "https://img2.pic.in.th/pic/message_8604199.md.png",
    };
    notifications.push(notification);
  
    res.send("ลบส่วนผสมสำเร็จ");
  });
  
  
//API อัปเดควัตถุดิบหลังทำ
app.post("/api/save-ingredients", (req, res) => {
    const { newingredients } = req.body;
  
    console.log("วัตถุดิบที่ใช้", newingredients);
    newingredients.forEach((item) => {
      // แยกชื่อและจำนวนจาก string
      const parts = item.split(" ");
      const name = parts[0]; // เช่น "หมูสับ"
  
      const quantityToRemove = parseInt(parts[1]) || 0; // เช่น 2 (ถ้าไม่มีจำนวน default เป็น 1)
  
      // หาวัตถุดิบในคลัง
      const existingItem = ingredients.find((ing) => ing.name === name);
      if (existingItem) {
        existingItem.quantity -= quantityToRemove; // ลบจำนวน
        if (existingItem.quantity < 0) existingItem.quantity = 0; // ป้องกันติดลบ
      } else {
        console.log(`ไม่พบ "${name}" ในคลัง`);
      }
    });
  
    res.json({ status: "success", message: "อัปเดตวัตถุดิบเรียบร้อย" });
  });
  