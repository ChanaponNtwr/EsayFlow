
// API ดึงการแจ้งเตือนทั้งหมด
app.get("/api/notifications", (req, res) => {
    res.json(notifications);
  });
  
  // API ลบการแจ้งเตือนทั้งหมด
  app.delete("/api/notifications", (req, res) => {
    notifications = [];
    res.send("ลบการแจ้งเตือนทั้งหมดสำเร็จ");
  });

  // API บันทึกเมนูที่เลือก
app.post("/api/menu-select", (req, res) => {
    const { name, image, ingredients } = req.body;
    console.log("เมนูที่เลือก:", { name, image, ingredients });
    res.json({ status: "success", message: "บันทึกการเลือกเมนูเรียบร้อย" });
  });
  