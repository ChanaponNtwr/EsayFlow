const router = require('express').Router()

router.use('/api/v1/user', require('./user.route'))
router.use('/api/v1/product', require('./user.route'))

module.exports = router