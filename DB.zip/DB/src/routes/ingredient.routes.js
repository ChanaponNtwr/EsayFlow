const express = require('express');
const router = express.Router();
const { addIngredientToJson } = require('../controllers/ingredient.controller');
const uploadImage = require('../middleware/uploadImage');  // ใช้ middleware สำหรับอัปโหลดภาพ

// Route สำหรับเพิ่มวัตถุดิบ
router.post('/add', uploadImage, addIngredientToJson);

module.exports = router;
