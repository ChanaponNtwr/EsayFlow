const express = require('express')
const app = express()

require('./src/models')
// app.use('/', require('./routes'))

app.listen(5000, () => {
    console.log(`Server start http://localhost:`+ 5000)
})